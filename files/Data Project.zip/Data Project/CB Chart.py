import matplotlib.pyplot as plt
import os.path
import numpy as np

# Naming the current directory
directory = os.path.dirname(os.path.abspath(__file__))  

# Create lists for x and y values
years=[]
number_of_people=[]
filenumIndicators = ["6-7", "8-9", "10-11", "12-13"]
labels = ["6", "7", "8", "9", "10", "11", "12", "13"]
N = 4
ind = np.arange(N)
width = 0.75

# Get filepath

filename = os.path.join(directory, 'Overall Data.txt')
datafile = open(filename,'r') # 'r' means 'read-only'
data = datafile.readlines()


# For each line in the file...
for line in data[1:]: #Skips first line of the csv file since it is only labels
    
    # Split the line into the three separate pieces of info
    year, number, total = line.split('\t')
    
    # If the name matches...
    # Add the x and y values to the lists
    years.append(str(year))
    number_of_people.append(int(number))           
datafile.close()

fig, ax = plt.subplots(1,1)
ax.bar(range(4), number_of_people) 

ax.set_ylabel('Number of People Cyber-Bullied')
ax.set_xlabel('Years')
ax.set_title('Cyber-Bullying Over Time')
ax.set_xticklabels(years)
ax.set_xticks(ind + width / 2)

fig.show()

